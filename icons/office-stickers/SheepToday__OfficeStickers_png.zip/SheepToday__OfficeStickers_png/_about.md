# Sheep.Today Office Stickers

v2018.1.23 - in russian


## Home page

http://sheep.today/icons/office-stickers/


## Author info

zl 2018
Riga, Latvia

If you are interested in commercial use
Please ask the permissions by e-mail

sheep.today@gmail.com
